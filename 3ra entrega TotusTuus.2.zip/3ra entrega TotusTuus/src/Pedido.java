
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fapal
 */
public class Pedido extends Cliente{
    
    private List<Cliente> listaDatosCliente;
    private String estado;
    private int CantidadVelas;

    public Pedido(List<Cliente> listaDatosCliente, String estado, int CantidadVelas) {
        
        this.listaDatosCliente = listaDatosCliente;
        this.estado = estado;
        this.CantidadVelas = CantidadVelas;
    }
    
    public Pedido() {
        
    }

    public List<Cliente> getListaDatosCliente() {
        return listaDatosCliente;
    }

    public void setListaDatosCliente(String nombre, String nit, String direccion) {
    
        Cliente nuevoCliente = new Cliente();
        nuevoCliente.setNombre(nombre);
        nuevoCliente.setNit(nit);
        nuevoCliente.setDireccion(direccion);
        
        if (listaDatosCliente == null) {
            listaDatosCliente = new ArrayList<>();
        }
        
        listaDatosCliente.add(nuevoCliente);
        
        for (Cliente cliente : listaDatosCliente) {
            System.out.println(listaDatosCliente.indexOf(cliente) + 1);
            System.out.println("Pedido= \n Nombre: "+cliente.getNombre()+"\n"+" Nit: "+cliente.getNit()+"\n" + " Dirección: "+cliente.getDireccion()+"\n");
        }
        
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getCantidadVelas() {
        return CantidadVelas;
    }

    public void setCantidadVelas(int CantidadVelas) {
        this.CantidadVelas = CantidadVelas;
    }

    
    
    
    
    
    
    
    

}
